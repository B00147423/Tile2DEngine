#pragma once
#pragma once

struct GridSettings {
    float cellWidth, cellHeight;
    int rows, cols;
};
