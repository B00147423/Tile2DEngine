﻿#include "Editor.h"

void Editor::handleEntityPlacement() {
    // Skip if in play mode (room is frozen)
    if (playMode)
        return;
    
    // Skip if mouse is over ImGui
    if (ImGui::GetIO().WantCaptureMouse)
        return;

    GLFWwindow* wnd = m_window.getHandle();

    bool leftPressed   = glfwGetMouseButton(wnd, GLFW_MOUSE_BUTTON_LEFT)   == GLFW_PRESS;
    bool rightPressed  = glfwGetMouseButton(wnd, GLFW_MOUSE_BUTTON_RIGHT)  == GLFW_PRESS;
    bool middlePressed = glfwGetMouseButton(wnd, GLFW_MOUSE_BUTTON_MIDDLE) == GLFW_PRESS;

    // Do nothing while panning camera
    if (middlePressed)
        return;

    // Edge detection
    static bool leftWasPressed  = false;
    static bool rightWasPressed = false;

    bool leftClick  = leftPressed  && !leftWasPressed;
    bool rightClick = rightPressed && !rightWasPressed;

    leftWasPressed  = leftPressed;
    rightWasPressed = rightPressed;

    // Only react on click DOWN
    if (!leftClick && !rightClick)
        return;

    glm::vec2 pos = getMouseWorldPosition();

    float halfRoomW = gameViewWidth * 0.5f;
    float halfRoomH = gameViewHeight * 0.5f;

    //GRID ORIGIN — MUST MATCH drawInfiniteGrid()
    float gridOriginX = -halfRoomW;
    float gridOriginY = -halfRoomH;

    // Mouse in world space

    // Convert world → grid-local
    float localX = pos.x - gridOriginX;
    float localY = pos.y - gridOriginY;

    // Grid indices
    int gx = (int)std::floor(localX / cellWidth);
    int gy = (int)std::floor(localY / cellHeight);

    // Clamp to room
    if (gx < 0 || gx >= currentScene.grid.cols ||
        gy < 0 || gy >= currentScene.grid.rows)
    {
        return;
    }

    // Convert back to world (cell center)
    float snappedX = gridOriginX + gx * cellWidth + cellWidth * 0.5f;
    float snappedY = gridOriginY + gy * cellHeight + cellHeight * 0.5f;


    // ===== LEFT CLICK — PLACE =====
    if (leftClick) {
        Entity entity;
        entity.type  = selectedType;
        entity.x     = snappedX;
        entity.y     = snappedY;
        entity.layer = placementLayer;

        bool alreadyPlaced = false;
        for (auto& e : currentScene.entities) {
            if (e.layer == entity.layer &&
                std::abs(e.x - entity.x) < 0.1f &&
                std::abs(e.y - entity.y) < 0.1f) {
                alreadyPlaced = true;
                break;
            }
        }

        if (!alreadyPlaced) {
            currentScene.entities.push_back(entity);
            entitiesNeedSorting = true;
        }
    }

    // ===== RIGHT CLICK — REMOVE =====
    if (rightClick) {
        for (auto it = currentScene.entities.begin(); it != currentScene.entities.end(); ++it) {
            if (std::abs(it->x - snappedX) < cellWidth * 0.5f &&
                std::abs(it->y - snappedY) < cellHeight * 0.5f) {
                currentScene.entities.erase(it);
                entitiesNeedSorting = true;
                break;
            }
        }
    }
}

void Editor::processInput() {
    GLFWwindow* handle = m_window.getHandle();
    const float moveSpeed = 10.0f * zoom;

    if (glfwGetKey(handle, GLFW_KEY_W) == GLFW_PRESS) cameraY += moveSpeed;
    if (glfwGetKey(handle, GLFW_KEY_S) == GLFW_PRESS) cameraY -= moveSpeed;
    if (glfwGetKey(handle, GLFW_KEY_A) == GLFW_PRESS) cameraX -= moveSpeed;
    if (glfwGetKey(handle, GLFW_KEY_D) == GLFW_PRESS) cameraX += moveSpeed;

    m_camera.setPosition(cameraX, cameraY);
}

void Editor::handlePlayerMovement() {
    if (!playMode || !activeRoom) return;
    
    GLFWwindow* handle = m_window.getHandle();
    
    // Skip if ImGui wants keyboard input
    if (ImGui::GetIO().WantCaptureKeyboard) return;
    
    // Find the player entity
    Entity* playerEntity = nullptr;
    for (auto& e : activeRoom->entities) {
        if (e.type == playerEntityType) {
            playerEntity = &e;
            break;
        }
    }
    
    if (!playerEntity) return;  // No player entity found
    
    // Get delta time for smooth movement
    float deltaTime = ImGui::GetIO().DeltaTime;
    
    // Movement speed in pixels per second (adjust this value to change speed)
    const float moveSpeed = 200.0f;  // pixels per second
    
    // Check which keys are pressed
    bool wPressed = glfwGetKey(handle, GLFW_KEY_W) == GLFW_PRESS;
    bool sPressed = glfwGetKey(handle, GLFW_KEY_S) == GLFW_PRESS;
    bool aPressed = glfwGetKey(handle, GLFW_KEY_A) == GLFW_PRESS;
    bool dPressed = glfwGetKey(handle, GLFW_KEY_D) == GLFW_PRESS;
    
    // Calculate movement direction
    float moveX = 0.0f;
    float moveY = 0.0f;
    
    if (wPressed) moveY += 1.0f;  // Up (Y increases upward)
    if (sPressed) moveY -= 1.0f;   // Down
    if (aPressed) moveX -= 1.0f;   // Left
    if (dPressed) moveX += 1.0f;   // Right
    
    // Normalize diagonal movement (so diagonal isn't faster)
    if (moveX != 0.0f && moveY != 0.0f) {
        moveX *= 0.707f;  // 1/sqrt(2) for diagonal normalization
        moveY *= 0.707f;
    }
    
    // Calculate new position
    float newX = playerEntity->x + moveX * moveSpeed * deltaTime;
    float newY = playerEntity->y + moveY * moveSpeed * deltaTime;
    
    // Calculate room bounds for clamping
    float halfRoomW = gameViewWidth * 0.5f;
    float halfRoomH = gameViewHeight * 0.5f;
    float gridOriginX = -halfRoomW;
    float gridOriginY = -halfRoomH;
    
    int roomCols = runtimeRoom.cols;
    int roomRows = runtimeRoom.rows;
    
    // Clamp to room bounds (with half-cell padding so entity doesn't go outside)
    float minX = gridOriginX + cellWidth * 0.5f;
    float maxX = gridOriginX + roomCols * cellWidth - cellWidth * 0.5f;
    float minY = gridOriginY + cellHeight * 0.5f;
    float maxY = gridOriginY + roomRows * cellHeight - cellHeight * 0.5f;
    
    newX = std::max(minX, std::min(maxX, newX));
    newY = std::max(minY, std::min(maxY, newY));
    
    // Update player position
    playerEntity->x = newX;
    playerEntity->y = newY;
}

glm::vec2 Editor::getMouseWorldPosition() {
    // Get current window size (updated each frame in run loop)
    int currentWidth, currentHeight;
    glfwGetWindowSize(m_window.getHandle(), &currentWidth, &currentHeight);

    double mouseX, mouseY;
    glfwGetCursorPos(m_window.getHandle(), &mouseX, &mouseY);

    // Viewport dimensions (grid area, excluding left panel)
    int viewportWidth = currentWidth - kLeftPanelWidth;
    int viewportHeight = currentHeight;

    // Convert mouse position to viewport coordinates
    float viewX = static_cast<float>(mouseX) - kLeftPanelWidth;
    float viewY = static_cast<float>(mouseY);

    // Flip Y axis (OpenGL Y=0 is at bottom, screen Y=0 is at top)
    viewY = viewportHeight - viewY;

    // Normalize to [-1, 1] range in viewport space
    float normalizedX = (viewX / viewportWidth) * 2.0f - 1.0f;
    float normalizedY = (viewY / viewportHeight) * 2.0f - 1.0f;

    // Get camera properties
    glm::vec2 camPos = m_camera.getPosition();
    float zoom = m_camera.getZoom();

    // Match camera projection calculation exactly
    // Camera uses virtual size (default 1280x720) and aspect ratio

    float viewWidth = gameViewWidth;
    float viewHeight = gameViewHeight;
    float aspect = static_cast<float>(viewportWidth) / static_cast<float>(viewportHeight);

    float halfHeight = (viewHeight * 0.5f) / zoom;
    float halfWidth = halfHeight * aspect;


    // Convert normalized coordinates to world space
    float worldX = camPos.x + normalizedX * halfWidth;
    float worldY = camPos.y + normalizedY * halfHeight;

    return { worldX, worldY };
}
