#pragma once
#include "RoomAsset.h"
#include "Tile.h"
#include <vector>

std::vector<TileType> BuildRoomTiles(const RoomAsset& room);
void ApplyDoors(const RoomAsset& room, std::vector<TileType>& tiles);
