#pragma once
#pragma once

enum class TileType {
    Floor,
    Wall,
    CornerTL,
    CornerTR,
    CornerBL,
    CornerBR
};
