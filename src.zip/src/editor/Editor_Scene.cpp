﻿#include "Editor.h"
#include "SceneSerializer.h"
#include "SceneToRoomAsset.h"

/**
 * New scene: Creates a blank new scene with the given name.
 * Sets scene name, initializes grid settings from current cellWidth/cellHeight,
 * clears all entities, and sets entitiesNeedSorting=false (empty list doesn't need sorting).
 * Called when user clicks "New Scene" or from menu.
 */
void Editor::newScene(const std::string& name) {
    currentScene.name = name;
    currentScene.entities.clear();

    // Grid definition (15 x 9)
    currentScene.grid = { cellWidth, cellHeight, 9, 15 };

    // ROOM SIZE DERIVED FROM GRID — ALWAYS
    gameViewWidth = currentScene.grid.cols * cellWidth;   // 15 * 32 = 480
    gameViewHeight = currentScene.grid.rows * cellHeight;  //  9 * 32 = 288

    // Store for save/load only
    currentScene.gameViewWidth = gameViewWidth;
    currentScene.gameViewHeight = gameViewHeight;

    entitiesNeedSorting = false;
}



/**
 * Save scene: Saves the current scene to disk in both binary (.map) and JSON (.json) formats.
 * Binary format is fast for runtime loading, JSON is human-readable for debugging.
 * Uses SceneSerializer to do the actual file writing. Sets currentScene.path after
 * successful save. Prints errors if file operations fail. Called when user saves.
 */
void Editor::saveScene(const std::string& path) {
    // Sync current editor values to scene before saving
    currentScene.gameViewWidth = gameViewWidth;
    currentScene.gameViewHeight = gameViewHeight;
    
    // Binary for runtime (fast)
    if (!SceneSerializer::saveBinary(currentScene, path + ".map")) {
        std::cerr << "Failed to save binary scene: " << path + ".map" << "\n";
        return;
    }

    // JSON for debugging readable
    if (!SceneSerializer::saveJSON(currentScene, path + ".json")) {
        std::cerr << "Failed to save JSON scene: " << path + ".json" << "\n";
        return;
    }

    currentScene.path = path + ".map";
    std::cout << "Saved scene: " << currentScene.name << " → " << path << "\n";
}

/**
 * Load scene: Loads a scene from a binary .map file.
 * Uses SceneSerializer to read the binary file, populates currentScene with the
 * loaded data (name, grid settings, entities), sets the scene path, and marks
 * entities for sorting. Prints error if file doesn't exist or is invalid.
 * Called when user opens a scene from the dialog.
 */
void Editor::loadScene(const std::string& path) {
    if (!SceneSerializer::loadBinary(currentScene, path)) {
        std::cerr << "Failed to load binary scene: " << path << "\n";
        return;
    }

    currentScene.path = path;

    // Set the name from the path (if the serializer didn't do it)
    currentScene.name = fs::path(path).stem().string();

    // Sync loaded scene values to editor UI
    gameViewWidth = currentScene.gameViewWidth;
    gameViewHeight = currentScene.gameViewHeight;
    
    // Update camera virtual size when loading scene (not during editing)
    m_camera.setVirtualSize(gameViewWidth, gameViewHeight);

    entitiesNeedSorting = true;
    cachedTexturePaths.clear();

    std::cout << "Loaded scene: " << currentScene.name << " (" << path << ")\n";
}

/**
 * Toggle play mode: Switches between editor mode and play mode.
 * When turning play mode ON: converts currentScene to runtimeRoom and sets activeRoom.
 * When turning play mode OFF: clears activeRoom to return to editor mode.
 */
void Editor::togglePlayMode() {
    playMode = !playMode;
    
    if (playMode) {
        // Convert Scene → RoomAsset and store in runtimeRoom
        runtimeRoom = BuildRoomAssetFromScene(currentScene);
        activeRoom = &runtimeRoom;
        std::cout << "Play Mode ON: Scene converted to runtime RoomAsset\n";
        std::cout << "  Editor entities: " << currentScene.entities.size() << "\n";
        std::cout << "  Runtime entities: " << runtimeRoom.entities.size() << "\n";
        std::cout << "  Room size: " << runtimeRoom.cols << "x" << runtimeRoom.rows << "\n";
    } else {
        // Return to editor mode
        activeRoom = nullptr;
        std::cout << "Play Mode OFF: Returned to editor mode\n";
        std::cout << "  Editor entities: " << currentScene.entities.size() << "\n";
    }
}
