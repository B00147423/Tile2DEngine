#pragma once
#include <vector>
#include <string>
#include "Entity.h"

struct RoomAsset {
    int rows = 9;
    int cols = 15;

    bool doorUp = false;
    bool doorDown = false;
    bool doorLeft = false;
    bool doorRight = false;

    std::vector<Entity> entities;
};
