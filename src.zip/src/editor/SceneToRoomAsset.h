#pragma once
#include "RoomAsset.h"
#include "Scene.h"

RoomAsset BuildRoomAssetFromScene(const Scene& scene);
