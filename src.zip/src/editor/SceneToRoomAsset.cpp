#include "SceneToRoomAsset.h"

RoomAsset BuildRoomAssetFromScene(const Scene& scene) {
    RoomAsset room;
    room.rows = scene.grid.rows;
    room.cols = scene.grid.cols;

    for (const auto& e : scene.entities) {
        if (e.type == "DoorUp")    room.doorUp = true;
        if (e.type == "DoorDown")  room.doorDown = true;
        if (e.type == "DoorLeft")  room.doorLeft = true;
        if (e.type == "DoorRight") room.doorRight = true;
    }

    room.entities = scene.entities;
    return room;
}
