#include "RoomBuilder.h"

std::vector<TileType> BuildRoomTiles(const RoomAsset& room) {
    std::vector<TileType> tiles(room.rows * room.cols);

    int maxX = room.cols - 1;
    int maxY = room.rows - 1;

    for (int y = 0; y < room.rows; y++) {
        for (int x = 0; x < room.cols; x++) {
            int i = y * room.cols + x;

            if (x == 0 && y == 0)
                tiles[i] = TileType::CornerBL;
            else if (x == maxX && y == 0)
                tiles[i] = TileType::CornerBR;
            else if (x == 0 && y == maxY)
                tiles[i] = TileType::CornerTL;
            else if (x == maxX && y == maxY)
                tiles[i] = TileType::CornerTR;
            else if (x == 0 || x == maxX || y == 0 || y == maxY)
                tiles[i] = TileType::Wall;
            else
                tiles[i] = TileType::Floor;
        }
    }

    return tiles;
}

void ApplyDoors(const RoomAsset& room, std::vector<TileType>& tiles) {
    int cx = room.cols / 2;
    int cy = room.rows / 2;

    if (room.doorUp)
        tiles[(room.rows - 1) * room.cols + cx] = TileType::Floor;

    if (room.doorDown)
        tiles[cx] = TileType::Floor;

    if (room.doorLeft)
        tiles[cy * room.cols] = TileType::Floor;

    if (room.doorRight)
        tiles[cy * room.cols + (room.cols - 1)] = TileType::Floor;
}
